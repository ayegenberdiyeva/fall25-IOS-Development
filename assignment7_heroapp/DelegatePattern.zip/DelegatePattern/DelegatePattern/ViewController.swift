//
//  ViewController.swift
//  DelegatePattern
//
//  Created by Arman Myrzakanurov on 20.11.2025.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet private weak var tableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
    }
}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
        cell.configure(id: "\(indexPath.row)")
        cell.delegate = self
        return cell
    }
}

extension ViewController: TableViewCellDelegate {
    func onButtonDidTap(id: String) {
        print("Cell Id: \(id)")
        performSegue(withIdentifier: "detail", sender: nil)
    }
}
