//
//  TableViewCell.swift
//  DelegatePattern
//
//  Created by Arman Myrzakanurov on 20.11.2025.
//

import UIKit

protocol TableViewCellDelegate {
    func onButtonDidTap(id: String)
}

class TableViewCell: UITableViewCell {

    @IBOutlet private weak var titleLabel: UILabel!
    var delegate: TableViewCellDelegate?
    private var id: String = ""

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    func configure(id: String) {
        self.id = id
    }

    @IBAction private func buttonDidTap(_ sender: UIButton) {
        delegate?.onButtonDidTap(id: id)
    }
}
